var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__58e44903._.js")
R.c("server/chunks/Desktop_my-emm__next-internal_server_app_favicon_ico_route_actions_6fda40b2.js")
R.m(84935)
module.exports=R.m(84935).exports
