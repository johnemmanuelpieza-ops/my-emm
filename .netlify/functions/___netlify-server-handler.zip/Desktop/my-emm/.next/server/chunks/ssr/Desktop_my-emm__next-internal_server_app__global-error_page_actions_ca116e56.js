module.exports=[3701,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_my-emm__next-internal_server_app__global-error_page_actions_ca116e56.js.map