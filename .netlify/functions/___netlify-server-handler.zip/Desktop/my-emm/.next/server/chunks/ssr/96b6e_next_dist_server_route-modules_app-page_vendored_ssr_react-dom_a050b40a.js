module.exports=[85766,(a,b,c)=>{"use strict";b.exports=a.r(42630).vendored["react-ssr"].ReactDOM}];

//# sourceMappingURL=96b6e_next_dist_server_route-modules_app-page_vendored_ssr_react-dom_a050b40a.js.map