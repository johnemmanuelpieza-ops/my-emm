module.exports=[23236,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_my-emm__next-internal_server_app_favicon_ico_route_actions_6fda40b2.js.map